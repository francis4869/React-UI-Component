declare const isFF: boolean;
export default isFF;
