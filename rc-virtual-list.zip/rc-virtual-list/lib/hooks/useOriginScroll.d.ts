declare const _default: (isScrollAtTop: boolean, isScrollAtBottom: boolean) => (deltaY: number, smoothOffset?: boolean) => boolean;
export default _default;
