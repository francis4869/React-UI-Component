import * as React from 'react';
import { ComponentType } from './Overflow';
export interface ItemProps<ItemType> {
    prefixCls: string;
    item?: ItemType;
    className?: string;
    style?: React.CSSProperties;
    renderItem?: (item: ItemType) => React.ReactNode;
    responsive?: boolean;
    itemKey?: React.Key;
    registerSize: (key: React.Key, width: number | null) => void;
    children?: React.ReactNode;
    display: boolean;
    order: number;
    component?: ComponentType;
}
export default function Item<ItemType>(props: ItemProps<ItemType>): JSX.Element;
