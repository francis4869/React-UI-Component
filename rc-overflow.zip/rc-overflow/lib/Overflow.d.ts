import * as React from 'react';
declare const RESPONSIVE: "responsive";
export declare type ComponentType = React.ComponentType<any> | React.ForwardRefExoticComponent<any> | React.FC<any> | keyof React.ReactHTML;
export interface OverflowProps<ItemType> extends React.HTMLAttributes<any> {
    prefixCls?: string;
    className?: string;
    style?: React.CSSProperties;
    data?: ItemType[];
    itemKey?: React.Key | ((item: ItemType) => React.Key);
    /** Used for `responsive`. It will limit render node to avoid perf issue */
    itemWidth?: number;
    renderItem?: (item: ItemType) => React.ReactNode;
    renderItemProps?: (item: ItemType) => React.HTMLAttributes<any>;
    maxCount?: number | typeof RESPONSIVE;
    renderRest?: React.ReactNode | ((omittedItems: ItemType[]) => React.ReactNode);
    suffix?: React.ReactNode;
    component?: ComponentType;
    itemComponent?: ComponentType;
}
declare const _default: <ItemType = any>(props: OverflowProps<ItemType> & {
    children?: React.ReactNode;
} & {
    ref?: React.Ref<HTMLDivElement>;
}) => React.ReactElement;
export default _default;
