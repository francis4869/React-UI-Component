import * as React from 'react';
import type { OptionsType } from '../interface';
export declare function convertChildrenToData(nodes: React.ReactNode, optionOnly?: boolean): OptionsType;
