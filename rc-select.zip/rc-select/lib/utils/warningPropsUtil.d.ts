import type { SelectProps } from '..';
declare function warningProps(props: SelectProps): void;
export default warningProps;
