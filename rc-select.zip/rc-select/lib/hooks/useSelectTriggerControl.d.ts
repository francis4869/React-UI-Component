export default function useSelectTriggerControl(elements: (HTMLElement | undefined)[], open: boolean, triggerOpen: (open: boolean) => void): void;
