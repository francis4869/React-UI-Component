import type { DisplayLabelValueType } from '../interface/generator';
export default function useCacheDisplayValue(values: DisplayLabelValueType[]): DisplayLabelValueType[];
