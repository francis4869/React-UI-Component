import * as React from 'react';
interface TriggerContextProps {
    onPopupMouseDown: React.MouseEventHandler<HTMLElement>;
}
declare const TriggerContext: React.Context<TriggerContextProps>;
export default TriggerContext;
