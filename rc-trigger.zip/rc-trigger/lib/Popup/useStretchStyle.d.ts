import * as React from 'react';
import type { StretchType } from '../interface';
declare const _default: (stretch?: StretchType) => [React.CSSProperties, (element: HTMLElement) => void];
export default _default;
