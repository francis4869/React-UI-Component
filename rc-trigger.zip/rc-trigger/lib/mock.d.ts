import * as React from 'react';
declare const _default: React.ComponentClass<import("./index").TriggerProps, any>;
export default _default;
