# History
----

## 4.1.0 / 2020-05-08

- upgrade rc-animate to `3.x`

## 2.5.0 / 2018-06-05

- support `alignPoint`

## 2.1.0 / 2017-10-16

- add action `contextMenu`

## 2.0.0 / 2017-09-25

- support React 16

## 1.11.0 / 2017-06-07

- add es

## 1.9.0 / 2017-02-27

- add getDocument prop

## 1.8.2 / 2017-02-24

- change default container to absolute to fix scrollbar change problem

## 1.7.0 / 2016-07-18

- use getContainerRenderMixin from 'rc-util'

## 1.6.0 / 2016-05-26

- support popup as function

## 1.5.0 / 2016-05-26

- add forcePopupAlign method

## 1.4.0 / 2016-04-06

- support onPopupAlign

## 1.3.0 / 2016-03-25

- support mask/maskTransitionName/zIndex

## 1.2.0 / 2016-03-01

- add showAction/hideAction

## 1.1.0 / 2016-01-06

- add root trigger node as parameter of getPopupContainer
