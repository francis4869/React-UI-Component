export default function get(entity: any, path: (string | number)[]): any;
