declare const _default: () => boolean;
export default _default;
