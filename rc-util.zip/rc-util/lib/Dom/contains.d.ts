export default function contains(root: Node | null | undefined, n?: Node): boolean;
