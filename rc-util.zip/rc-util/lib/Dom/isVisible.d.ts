declare const _default: (element: HTMLElement | SVGGraphicsElement) => boolean;
export default _default;
