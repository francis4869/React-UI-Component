export default function canUseDom(): boolean;
