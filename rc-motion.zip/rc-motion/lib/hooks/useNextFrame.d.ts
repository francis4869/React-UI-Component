declare const _default: () => [(callback: (info: {
    isCanceled: () => boolean;
}) => void) => void, () => void];
export default _default;
