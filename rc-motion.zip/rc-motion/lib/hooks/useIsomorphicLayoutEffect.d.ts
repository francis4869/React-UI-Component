import { useEffect } from 'react';
declare const useIsomorphicLayoutEffect: typeof useEffect;
export default useIsomorphicLayoutEffect;
