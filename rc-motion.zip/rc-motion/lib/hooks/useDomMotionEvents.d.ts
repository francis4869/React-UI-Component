import { MotionEvent } from '../interface';
declare const _default: (callback: (event: MotionEvent) => void) => [(element: HTMLElement) => void, (element: HTMLElement) => void];
export default _default;
